const distance = (a, b) => {
	
	if(typeof(a) != 'string' || typeof(b) != 'string')
		throw new Error('InvalidType');
	if(a.length == 0 && b.length == 0)
	return 0;
	var matrix = [];
	for(let i = 0; i <= a.length; i++){var array = []
		for(let j = 0; j <= b.length; j++){
		
			if(i == 0){
				array[j] = j;
			}
			else
				if(j == 0){
					array[j] = i;
				}
				else
				array[j] = 0;
		}
		matrix[i] = array;
	}		//matrix initialization

	for(let i = 1; i <= a.length; i++){
		for(let j = 1; j <= b.length; j++){
			
				if(a[i-1] == b[j-1])
				matrix[i][j] = matrix[i-1][j-1];
			else{
				min = matrix[i-1][j-1];
				if(matrix[i-1][j] < min)
					min = matrix[i-1][j];
				else if(matrix[i][j-1] < min)
					min = matrix[i][j-1];
				matrix[i][j] = min+1;
				}
		}
	}
	return matrix[a.length][b.length];	
}



module.exports.distance = distance